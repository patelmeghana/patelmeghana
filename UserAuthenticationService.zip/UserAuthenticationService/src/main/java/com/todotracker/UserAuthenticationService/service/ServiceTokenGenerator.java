package com.todotracker.UserAuthenticationService.service;
import java.util.Map;

import com.todotracker.UserAuthenticationService.domain.User;

public interface ServiceTokenGenerator {
    Map<String, String> generateToken(User user);

    Object generaterToken(User user2);
}
