package com.todotracker.UserAuthenticationService.service;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.todotracker.UserAuthenticationService.domain.User;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class ServiceTokenGeneratorIpl  implements ServiceTokenGenerator{

    @Override
    public Map<String, String> generateToken(User user) {
        String JwtToken = Jwts.builder()
                .setSubject(Integer.toString(user.getUserId()))
                .setIssuedAt(new Date())
                .signWith(SignatureAlgorithm.HS256, "user@123")
                .compact();
        Map<String, String> tokenMap = new HashMap<>();
        tokenMap.put("message", "Login Successful");
        tokenMap.put("token", JwtToken);
        return tokenMap;
    }

    @Override
    public Object generaterToken(User user2) {
        return null;
    }
}
