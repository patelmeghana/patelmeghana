package com.todotracker.UserAuthenticationService.service;
import com.todotracker.UserAuthenticationService.domain.User;
import com.todotracker.UserAuthenticationService.exception.UserAlreadyExistsException;
import com.todotracker.UserAuthenticationService.exception.UserNotFoundException;

public interface UserService {
    User saveNewUser(User user) throws UserAlreadyExistsException;
    User getUserByEmailAndPassword(String email, String password) throws UserNotFoundException;
    int getLatestUserID();
}
