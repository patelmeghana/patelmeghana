package com.todotracker.UserAuthenticationService.service;


import com.todotracker.UserAuthenticationService.domain.User;
import com.todotracker.UserAuthenticationService.exception.UserAlreadyExistsException;
import com.todotracker.UserAuthenticationService.exception.UserNotFoundException;
import com.todotracker.UserAuthenticationService.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private com.todotracker.UserAuthenticationService.service.UserServiceImpl userService;
    private User user,user2;
    List<User>userList;


    @BeforeEach
    void setUp(){
        user=new User(1,"Meghana","maggi12@gmail.com","123654");
        user2=new User(2,"Sravina","srava01@gmail.com","654321");
        userList= Arrays.asList(user,user2);

    }

    @AfterEach
    public void tearUp(){

        userList =null;
        user=null;
        user2=null;
    }

    @Test
    public void givenUserToSaveReturnTrue() throws UserAlreadyExistsException {

        when(userRepository.findById(user.getUserId())).thenReturn(Optional.ofNullable(null));
        when(userRepository.save(any())).thenReturn(user);

        assertEquals(user,userService.saveNewUser(user));
        verify(userRepository,times(1)).save(any());
        verify(userRepository,times(1)).findById(any());
    }

    @Test
    public void givenUserToSaveReturnFalse() throws UserAlreadyExistsException {

        when(userRepository.findById(user.getUserId())).thenReturn(Optional.ofNullable(user));
        assertThrows(UserAlreadyExistsException.class,()->userService.saveNewUser(user));

        verify(userRepository,times(0)).save(any());
        verify(userRepository,times(1)).findById(any());
    }

    @Test
    public void getUserByEmailAndPasswordTrue() throws UserNotFoundException {

        when(userRepository.findUserByEmailAndPassword(anyString(), anyString())).thenReturn(user);
        userRepository.save(user);
        assertEquals(user.getUserId(),userService.getUserByEmailAndPassword("sidh12@gmail.com","123654").getUserId());
        verify(userRepository,times(1)).findUserByEmailAndPassword(any(),any());

    }

    @Test
    public void getUserByEmailAndPasswordFalse() throws UserNotFoundException {

        when(userRepository.findUserByEmailAndPassword(anyString(), anyString())).thenReturn(user);
        userRepository.save(user);
        assertNotEquals(user2.getUserId(),userService.getUserByEmailAndPassword("sidh12@gmail.com","123654").getUserId());
        verify(userRepository,times(1)).findUserByEmailAndPassword(any(),any());

    }

    @Test
    public void getLatestUserIDTestTrue(){

        when(userRepository.findAll()).thenReturn(userList);
        userRepository.save(user);
        userRepository.save(user2);
        assertEquals(user2.getUserId(),userService.getLatestUserID());
        verify(userRepository,times(1)).findAll();

    }

    @Test
    public void getLatestUserIDTestFalse(){

        when(userRepository.findAll()).thenReturn(userList);
        userRepository.save(user);
        userRepository.save(user2);
        assertNotEquals(user.getUserId(),userService.getLatestUserID());
        verify(userRepository,times(1)).findAll();

    }
}
